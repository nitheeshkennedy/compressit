Usage
The following steps explains the usage of the application,
�	Extract the Compressit.zip
�	Go to Compressit/dist folder
�	Configure the gulpfile.js
o	Give proper paths for the js and css files� folders for which needs to be compressed.
o	src_jsPath will hold the source path for the Js folder
o	src_cssPath will hold the source path for the Css folder
o	dest_jsPath will hold the source path for the Js folder
o	dest_cssPath will hold the source path for the Css folder
o	Save the file after doing the changes
NOTE: By default the destination folders will be created in the Compressit folder itself. Feel free to change it
�	Run the compressit.exe
�	Check for the minified files in the destination given

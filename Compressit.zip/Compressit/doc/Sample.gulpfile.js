var gulp = require('gulp');
var minify = require('gulp-minify'), minifyCss = require("gulp-minify-css"), rename = require("gulp-rename");
var jsPath, cssPath;
var uglify = require('gulp-uglify');

jsPath = 'D:/Projects/AngularJs_Workspace/eClaims/DEPLOYMENT/20170824/testing/eClaims v3.1 QA/js';
cssPath = 'D:/Projects/AngularJs_Workspace/eClaims/DEPLOYMENT/20170824/testing/eClaims v3.1 QA/css';

gulp.task('default', function() {
  gulp.start('compressJs');
  gulp.start('compressCss');
});

//gulp.task('compressJs', function() {
//  gulp.src(jsPath + "/**/*.js")
/*    .pipe(minify({
        ext:{
            min:'.min.js'
        },
        exclude: ['angular'],
        ignoreFiles: ['*.combo.js', '*.min.js']
    }))
    .pipe(gulp.dest('js/'))
});*/

gulp.task('compressJs', function () {
	gulp.src(jsPath + "/**/*.js")
	.pipe(uglify())
	.pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest('js/'))
});

gulp.task('compressCss', function() {
  gulp.src(cssPath + "/**/*.css")
  .pipe(minifyCss())
  .pipe(rename({ suffix: '.min' }))
  .pipe(gulp.dest('css/'))
});